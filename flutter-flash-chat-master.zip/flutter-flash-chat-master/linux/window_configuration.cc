#include "window_configuration.h"

const char *kFlutterWindowTitle = "flutter_flash_chat";
const unsigned int kFlutterWindowWidth = 800;
const unsigned int kFlutterWindowHeight = 600;
