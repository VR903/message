# Flutter FlashChat

A chatting app built using Flutter and Firebase

Screencast:

<img src="/screencast/flash_chat.gif" width="300">
