package com.example.flutter_flash_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
